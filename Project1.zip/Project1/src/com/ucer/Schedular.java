package com.ucer;

public class Schedular {
	//private Course[] course=new Course[10];
	
private Student[] student=new Student[10];
private Course[] course=new Course[10];
private Faculty[] faculty=new Faculty[10];
private Batch[]  batch=new Batch[10];
private int studentCounter;
private int facultyCounter;
private int courseCounter;
private int batchCounter;
private int batchidCounter;
private int i,j;
//ENLARGE COURSE ARRAY
private void enlargeCourseArray()
{
	Course[] courseObj=new Course[courseCounter*2];
	for(i=0;i<courseCounter;i++)
	{
		courseObj[i]=course[i];
	}
	course=courseObj;
}
//ENLARGE STUDENT ARRAY
private void enlargeStudentArray()
{
	Student[] studentObj=new Student[studentCounter*2];
	for(i=0;i<studentCounter;i++)
	{
		studentObj[i]=student[i];
	}
	student=studentObj;
}
//ENLARGE FACULTY ARRAY
private void enlargeFacultyArray()
{
	Faculty[] facultyObj=new Faculty[facultyCounter*2];
	for(i=0;i<facultyCounter;i++)
	{
		facultyObj[i]=faculty[i];
	}
	faculty=facultyObj;
}
//ENLARGE BATCH ARRAY
private void enlargeBatchArray()
{
	Batch[] batchObj=new Batch[batchCounter*2];
	for(i=0;i<batchCounter;i++)
	{
		batchObj[i]=batch[i];
	}
	batch=batchObj;
}
//IS COURSE PRESENT
public boolean isCoursePresent(String course_name)
{
	if(courseCounter==0)
		return false;
	for(i=0;i<courseCounter;i++){
		if((course[i].getCourseName()).equals(course_name))
			return true;
	}
	return false;
}
//IS RNO PRESENT
public boolean isRnoPresent(int rno)
{
	if(studentCounter==0)
		return false;
	for(i=0;i<studentCounter;i++){
		if(student[i].getRno()==rno)
			return true;
	}
	return false;
}
//IS FACULTY PRESENT
public boolean isFacultyPresent(String facultyName)
{
	if(facultyCounter==0)
		return false;
	for(i=0;i<facultyCounter;i++){
		if(facultyName.equals(faculty[i].getFacultyName()))
			return true;
	}
	return false;
}
//IS BATCH ID PRESENT
public boolean isBatchidPresent(String batchid)
{
	if(batchCounter==0)
		return false;
	for(i=0;i<batchCounter;i++)
	{
		if((batchid.toUpperCase()).equals(batch[i].getBatchid()))
		{
			return true;
	}
	}
	return false;
}

//IS VALID COURSE
public boolean isValidCourse(int rno,String courseName)
{
	for(i=0;i<studentCounter;i++)
	{
		for(j=0;j<student[i].getCourses().length;j++)
		{
			if(rno==student[i].getRno() && courseName.equals(student[i].getCourses()[j].getCourseName()))
			{
				return true;
			}
		}
	}
     	return false;
}
//ADD COURSE
public String addCourse(String courseName)
{
	if(courseCounter==course.length)
	{
		enlargeCourseArray();
	}
	course[courseCounter++]=new Course(courseName);
	return "course added auccessfully";
}
//ADD STUDENT
public String addStudent( int rno,String name,String[] coursenames)
{
	if(studentCounter==student.length)
	{
		enlargeStudentArray();
	}
	Course[] tempCourses=new Course[coursenames.length];
	for(i=0;i<coursenames.length;i++)
	{
		tempCourses[i]=new Course(coursenames[i]);
		
	}
	student[studentCounter++]=new Student(rno,name,tempCourses);
	return "Student added auccessfully";
}
//ADD BATCH
public String addBatch( String courseName,String facultyName,int[] rno)
{
	if(batchCounter==batch.length)
	{
		enlargeBatchArray();
	}
	Student[] tempStudent=new Student[rno.length];
	int tempStudentCounter=0;
	for(i=0;i<studentCounter;i++)
	{
		for(j=0;j<rno.length;j++)
		{
			if(student[i].getRno()==rno[j])
			{
				tempStudent[tempStudentCounter++]=student[i];
			}
		}
	}
	batch[batchCounter++]=new Batch("B"+(++batchidCounter),courseName,facultyName,tempStudent);
	return "Batch B" +batchCounter+ "added successfully";
}
//ADD FACULTY
public String addFaculty( String facultyName,String[] courseName)

{
	if(facultyCounter==faculty.length)
	{
		enlargeFacultyArray();
	}
	Course[] tempCourses=new Course[courseName.length];
	for(i=0;i<tempCourses.length;i++)
	{
		tempCourses[i]=new Course(courseName[i]);
		
	}
	faculty[facultyCounter++]=new Faculty(facultyName,tempCourses);
	return "Faculty record added auccessfully";
}
//SHOW ALL COURSE
public String showAllCourses()
{

String courseList="";
for(i=0;i<courseCounter;i++)
{
	courseList+=course[i].getCourseName()+" ";
}return courseList;
}


//SHOW ALL SYUDENT
public String showAllStudent()
{
	
	String studentList=" ";
	for(i=0;i<studentCounter;i++)
	{
		studentList+=student[i].getRno()+" ";
	
		studentList+=student[i].getName()+" ";
	
		for(j=0;j<student[i].getCourses().length;j++)
		{
				studentList+=student[i].getCourses()[j].getCourseName()+" ";
			}
               studentList+="\n";
	}
	return studentList;
}
//SHOW ALL FACULTY
public String showAllFaculties()
{
	
	String facultyList=" ";
	for(i=0;i<facultyCounter;i++)
	{
		facultyList+=faculty[i].getFacultyName()+" ";
	
		
	
		for(j=0;j<faculty[i].getCourses().length;j++)
		{
				facultyList+=faculty[i].getCourses()[j].getCourseName()+" ";
				}
               facultyList+="\n";
	}
	return facultyList;
}
//SHOW ALL BATCHES
public String showAllBatches()
{
	
	String batchList=" ";
	for(i=0;i<batchCounter;i++)
	{
		batchList+=batch[i].getBatchid()+" "+batch[i].getCourseName()+" "+batch[i].getFacultyName();
	
		
	
		for(j=0;j<batch[i].getStudents().length;j++)
		{
				batchList+=batch[i].getStudents()[j].getRno()+" "+batch[i].getStudents()[j].getName()+" ";
				}
               batchList+="\n";
	}
	return batchList;
}
//SHOW STUDENT BY BATCH ID
public String showStudenstByBatchid(String batchid)
{
	String studentNames=" ";
	for(i=0;i<batchCounter;i++)
	{
if((batchid.toUpperCase()).equals(batch[i].getBatchid()))
{

		for(j=0;j<batch[i].getStudents().length;j++)
		{
			studentNames+=batch[i].getStudents()[j].getName()+" ,";
			
		}
break;
	}
	}
	return studentNames;
}
//SHOW STUDENT BY COURSE
public String showStudentByCourse(String courseName)
{
	String studentNames=" ";
	for(i=0;i<batchCounter;i++)
	{
		for(j=0;j<batch[i].getStudents().length;j++)
		{
			
		for(int k=0;k<batch[i].getStudents()[j].getCourses().length;k++)
		{
if(courseName.equals(batch[i].getStudents()[j].getCourses()[k].getCourseName()))
{
			studentNames+=batch[i].getStudents()[j].getName()+" ";
			
		}
		}
	}
	}
	return studentNames;
}

//SHOW STUDENT BY RNO
public String showStudentByRno(int rno)
{
	String studentRecord=" ";
	for(i=0;i<studentCounter;i++)
	{
if(student[i].getRno()==rno)
{

		studentRecord+=student[i].getName()+" ";
		for(j=0;j<student[i].getCourses().length;j++)
		{
			studentRecord+=student[i].getCourses()[j].getCourseName()+" ";
			
		}
break;
	}
	}
	return studentRecord;
}
//SHOW COURSE BY RNO
public String showCourseByRno(int rno)
{
	String courseName=" ";
	for(i=0;i<studentCounter;i++)
	{
if(rno==student[i].getRno())
{
		for(j=0;j<student[i].getCourses().length;j++)
		{
			courseName+=student[i].getCourses()[j].getCourseName()+" ";
			
		}

	}
	}
	return courseName;
}
//SHOW FACULTY BY RNO
public String showFacultyByRno(int rno)
{
	String facultyName="";
	boolean facultyRec=false;
	for(i=0;i<batchCounter;i++)
{
		for(j=0;j<batch[i].getStudents().length;j++)
		{
		if(rno==batch[i].getStudents()[j].getRno())
		{
		facultyName+=batch[i].getFacultyName();
		facultyRec=true;
		}
	}
}
if(facultyRec==false)
	facultyName+= "faculty is not assigned";
return facultyName;
}

//SHOW COURSES BY FACULTY
public String showCoursesByFaculty(String facultyName )
{
	String courseNames=" ";
	for(i=0;i<facultyCounter;i++)
	{
if(facultyName.equals(faculty[i].getFacultyName()))
{
		for(j=0;j<faculty[i].getCourses().length;j++)
		{
			courseNames+=faculty[i].getCourses()[j].getCourseName()+" ";
			
		}
break;
	}
	}
	return facultyName+  "knows"+  courseNames;
}

//SHOW COURSE BY BATCH ID
public String showCourseByBatchid(String batchid)
{
	String courseName="";
	for(i=0;i<batchCounter;i++)
{
		if((batchid.toUpperCase()).equals(batch[i].getBatchid()))
		{
		courseName+=batch[i].getCourseName();	
	}
}

return courseName;
}
//SHOW FACULTY BY BATCH ID
public String showFacultyByBatchid(String batchid)
{
	String facultyName="";
	for(i=0;i<batchCounter;i++)
{
		if((batchid.toUpperCase()).equals(batch[i].getBatchid()))
		{
		facultyName+=batch[i].getFacultyName();
		break;
	}
}

return facultyName;
}
//SHOW FACULTY BY COURSE
public String showFacultyByCourse(String courseName)
{
	String facultyNames="";
	boolean facultyRec=false;
	for(i=0;i<facultyCounter;i++)
{
		for(j=0;j<faculty[i].getCourses().length;j++)
		{
		if(courseName.equals(faculty[i].getCourses()[i].getCourseName()))
		{
				facultyNames+=batch[i].getFacultyName();
		facultyRec=true;
	}
}
}
	if(!facultyRec)
		facultyNames+="there is no faculty for" +courseName+ "course";
return facultyNames;
}

//SHOW STUDENT BY FACULTY
public String showStudentsByFaculty(String facultyName)
{
	
		String studentNames=" ";
		for(i=0;i<batchCounter;i++)
		{
	if(facultyName.equals(batch[i].getFacultyName()))
	{
			for(j=0;j<batch[i].getStudents().length;j++)
			{
				studentNames+=batch[i].getStudents()[j].getName()+" ";
				
			}
		}
		}
		return studentNames;
	}
//SHOW BATCH BY COURSE
public String showBatchByCourse(String courseName)
{
String batchids=" ";
boolean batchRec=false;
for(i=0;i<batchCounter;i++)
{
if(courseName.equals(batch[i].getCourseName()))
{
batchids+=batch[i].getBatchid();
batchRec=true;
}
}
if(!batchRec)
	batchids+="there is no batch for" +courseName+ "course";
return batchids;
}
//SHOW BATCH ID BY RNO

public String showBatchidsByRno(int rno)
{
String batchid=" ";
boolean batchidRec=false;
for(i=0;i<batchCounter;i++)
{
	for(j=0;j<batch[i].getStudents().length;j++)
	{
if(rno==batch[i].getStudents()[j].getRno())
{
batchid+=batch[i].getBatchid();
batchidRec=true;
}
}
}
if(batchidRec==false)
	batchid+="batch is not assigned";
return batchid;
}




//SHOW BATCH ID BY FACULTY

public String showBatchidsByFaculty(String facultyName)
 {
 String batchids=" ";
 for(i=0;i<batchCounter;i++)
 {
 if(facultyName.equals(batch[i].getFacultyName()))
 {
 batchids+=batch[i].getBatchid()+" ";
 }
 }
 return batchids;
 }
 
public int getStudentCounter()
{
	return studentCounter;
}
public int getFacultyCounter()
{
	return facultyCounter;
}

}


