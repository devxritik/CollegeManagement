package com.ucer;

public class Batch {
	private String batchid;
	private String courseName;
	String facultyName;
	private Student[] students;
		public Batch(String batchid, String courseName, String facultyName,
			Student[] students) {
		super();
		this.batchid = batchid;
		this.courseName = courseName;
		this.facultyName = facultyName;
		this.students = students;
	}
		public String getBatchid() {
			return batchid;
		}
		public void setBatchid(String batchid) {
			this.batchid = batchid;
		}
		public String getCourseName() {
			return courseName;
		}
		public void setCourseName(String courseName) {
			this.courseName = courseName;
		}
		public String getFacultyName() {
			return facultyName;
		}
		public void setFacultyName(String facultyName) {
			this.facultyName = facultyName;
		}
		public Student[] getStudents() {
			return students;
		}
		public void setStudents(Student[] students) {
			this.students = students;
		}
}
