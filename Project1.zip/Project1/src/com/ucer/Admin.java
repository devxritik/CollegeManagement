package com.ucer;
import java.util.Scanner;
public class Admin {
	private static Scanner sc=new Scanner(System.in);
	private static Schedular schedular=new Schedular();
	private static int i,j;
	private static String facultyName; 

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		showMenu();

	}
private static void showMenu()
{
	while(true)
	{
		System.out.println("------ADD-------");
		System.out.println("1 Add new course");
		System.out.println("2 Add new student");
		System.out.println("3 Add new facaulty");
		System.out.println("4 Add new batch");
		System.out.println("----SHOW-----");
		System.out.println("5 show course");
		System.out.println("6 show student");
		System.out.println("7 show facaulty");
		System.out.println("8 show batch");
		System.out.println("9 exit");
		System.out.println("Enter ur choice");
		int choice= sc.nextInt();
		switch(choice)
		{
		case 1:addCourse();
		break; 
		case 2:addStudent();
		break;
		case 3:addFaculty();
		break;
		case 4:addBatch();
		break;
		case 5:showCourse();
		break;
		case 6:showStudent();
		break;
		case 7:showFaculty();
		break;
		case 8:showBatch();
		break;
		case 9:System.exit(0);
		default :System.out.println("sorry u entered wrong choice");
		showMenu();
		}
		}
}
		//ADD COURSE
		private static void addCourse()
		{
			System.out.println("How many courses u want to enter");
			int noOfCourses=sc.nextInt();
			String[] courses=new String[noOfCourses];
			System.out.print("Enter "+noOfCourses+" courses");
			for(i=0;i<noOfCourses;i++)
			{
				while(true)
				{
					courses[i]=sc.next();
					if(schedular.isCoursePresent(courses[i]))
					{
						System.out.println("Duplicate course plz enter new course");
					}
	 break;
				}
			System.out.println(schedular.addCourse(courses[i]));
				
	}
		}
		//ADD STUDENT
		private static void addStudent()
		{
			int rno;
			int noOfCourses;
			int noOfStudents;
			String[] courses;
			System.out.println("How many student do u want to enter");
			 noOfStudents=sc.nextInt();
			//String[] courses=new String[noOfCourses];
			//System.out.print("Enter "+noOfCourses+" courses");
			for(i=0;i<noOfStudents;i++)
			{
				while(true)
				{
					System.out.println("enter the roll no");
					rno=sc.nextInt();
					
					
					if(schedular.isRnoPresent(rno))
					
						System.out.println("Roll no is already exist");
					else
	 break;
				}
				System.out.println("enter name");
				String name=sc.next();
				System.out.println("how many course do u want to register");
				noOfCourses=sc.nextInt();
				courses=new String[noOfCourses];
				for(int i=0;i<noOfCourses;i++)
				{
					while(true)
					{
						System.out.println("Enter" +(i+1)+ "courses");
						courses[i]=sc.next();
						if(schedular.isCoursePresent(courses[i]))
							break;
						else
							System.out.println("course does not exist");
						
					}
				}
			System.out.println(schedular.addStudent(rno,name,courses));
				
	}
		}
		//ADD FACULTY
		public static void addFaculty()
		{
			System.out.println("how many faculty do u want to add");
			int noOfFaculties=sc.nextInt();
			String facultyName=" ";
			String[] courseName;
			for(i=1;i<=noOfFaculties;i++)
			{
				System.out.println("enter faculty name");
				facultyName=sc.next();
				System.out.println("how many courses faculty knows");
				int noOfCourses=sc.nextInt();
				courseName=new String[noOfCourses];
				System.out.println("enter courses");
				for(j=0;j<noOfCourses;j++)
				{
					courseName[j]=sc.next();
				}
				System.out.println(schedular.addFaculty(facultyName,courseName));
			}
			
		}
		//ADD BATCH
		public static void addBatch()
		{
			if(schedular.getStudentCounter()==0)
			{
				System.out.println("there is no student to create batch");
				return;
			}
			if(schedular.getFacultyCounter()==0)
			{
				System.out.println("there is no faculty to create batch");
				return;
			}
			String courseName,facultyName;
			int noOfBatches;
			int noOfStudents;
			int[] rno;
			System.out.println("how many batches u want to add");
			noOfBatches=sc.nextInt();
			for(i=1;i<=noOfBatches;i++)
			{
				while(true)
				{
					System.out.println("enter course name");
					courseName=sc.next();
					if(!schedular.isCoursePresent(courseName))
					{
						System.out.println("course does not exist");
						
					}
					else{
						break;
					}
				}
				while(true){
					System.out.println("enter faculty name");
					facultyName=sc.next(); 
					if(!schedular.isFacultyPresent(facultyName))
						System.out.println("enter faculty name is invalid");
					else
						break;
				}
				System.out.println("how many student do u want to add");
				noOfStudents=sc.nextInt();
				rno=new int[noOfStudents];
				for(j=0;j<noOfStudents;j++)
				{
					while(true)
					{
						System.out.println("enter roll number");
						rno[j]=sc.nextInt();
						if(!schedular.isRnoPresent(rno[j]))
						{
							System.out.println("this student is not register for any course");
							
						}
						else if(!schedular.isValidCourse(rno[j], courseName))
						{
							System.out.println("entered roll no"+rno[j]+"is not register for the"+courseName);
							
						}
						else{
							break;
						}
					}
				}
				System.out.println(schedular.addBatch(courseName,facultyName,rno));
			}
		}
		//SHOW FACULTY
		private static void showFaculty()
		{
			int choice;
			 String facultyName = "";
			while(true)
			{
				System.out.println("1: show all faculties");
						System.out.println("2: show no of courses known by faculties");
						System.out.println("3: show students by faculty ");
						System.out.println("4: show batch ids  by faculty");
				
                        System.out.println("5: go to main menu");
						System.out.println("enter ur choice");
						
						 choice=sc.nextInt();
						 if(choice==5)
							break;
						 if(choice==2||choice==3||choice==4)
						 {
							 
							 
							 
								 System.out.println("enter faculty name");
								 facultyName=sc.next();
								 if(!schedular.isFacultyPresent(facultyName))
								 {
								 System.out.println("faculty does not exist");
								 }
						 }
								
						 switch(choice)
						{
						case 1: System.out.println(schedular.showAllFaculties());
						break;
						case 2:System.out.println(schedular.showCoursesByFaculty(facultyName));
					break;
						case 3:System.out.println(schedular.showStudentsByFaculty(facultyName));
						break;
						case 4:System.out.println(schedular.showBatchidsByFaculty(facultyName));
						break;
						
						}
						}
		}
		
		//SHOW STUDENT
		private static void showStudent()
		{
			int choice,rno=0;
			while(true)
			{
				System.out.println("1: show all student");
						System.out.println("2: show specific student by rno");
						System.out.println("3: show facaulty by rno");
						System.out.println("4: show course by rno");
						System.out.println("5: show batch id by rno");
                        System.out.println("6: go to main menu");
						System.out.println("enter ur choice");
						
						 choice=sc.nextInt();
						 if(choice==6)
							break;
						 if(choice==2||choice==3||choice==4||choice==5)
						 {
							 char userInput=' ';
							 while(true)
							 {
								 System.out.println("enter roll no");
								 rno=sc.nextInt();
								 if(schedular.isRnoPresent(rno))
									 break;
								 System.out.println("entered roll no does not exist");
								 System.out.println("want to enter another roll no(y/n)");
								 userInput=sc.next().charAt(0);
								 if(userInput!='y'||userInput!='Y')    
								 {
									 choice=6;
									 break;
								 }
							 }}
						switch(choice)
						{
						case 1: System.out.println(schedular.showAllStudent());
						break;
						case 2:System.out.println(schedular.showStudentByRno(rno));
					break;
						case 3:System.out.println(schedular.showFacultyByRno(rno));
						break;
						case 4:System.out.println(schedular.showCourseByRno(rno));
						break;
						case 5:System.out.println(schedular.showBatchidsByRno(rno));
						break;
						
						}
						}
		}
			//show batch
		private static void showBatch()
		{
		String batchid="";
		while(true)
		{
			System.out.println("1: show all batches");
			System.out.println("2: show student by batchid");
			System.out.println("3: show course name by batch id");
			System.out.println("4: show faculty name by batch id");
			System.out.println("5: go to main menu");
			System.out.println("enter ur choice");
			int choice=sc.nextInt();
			if(choice==5)
				break;
			if(choice==2||choice==3||choice==4)
			{
				while(true)
				{
					System.out.println("enter batch id");
					batchid=sc.next();
					if(schedular.isBatchidPresent(batchid))
						break;
					else
						System.out.println("entered batch id does not exist");
				}
			}
			switch(choice)
			{
			case 1: System.out.println(schedular.showAllBatches());
			break;
			case 2:System.out.println(schedular.showStudenstByBatchid(batchid));
			break;
			case 3:System.out.println(schedular.showCourseByBatchid(batchid));
			break;
			case 4:System.out.println(schedular.showFacultyByBatchid(batchid));
			break;
	
			}
		}
		
		}
		//SHOW COURSE
		private static void showCourse()
		{
			String courseName="";
			while(true)
			{
				System.out.println("1: show all courses");
						System.out.println("2: show facaulty by courses");
						System.out.println("3: show batch by courses");
						System.out.println("4: show student by courses");
						System.out.print("5: go to main menu");
						int choice=sc.nextInt();
						if(choice==5)
							break;
						if(choice==2||choice==3||choice==4)
						{
							System.out.println("enter course name");
							courseName=sc.next();
						}
						switch(choice)
						{
						case 1: System.out.print(schedular.showAllCourses());
						break;
					case 2:System.out.print(schedular.showFacultyByCourse(courseName));
					break;
						case 3:System.out.print(schedular.showBatchByCourse(courseName));
						break;
						case 4:System.out.print(schedular.showStudentByCourse(courseName));
						break;
						}
						}
		}
}


