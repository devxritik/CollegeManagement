package com.ucer;

public class Student {
	private int rno;
	private String name;
	private Course[] courses;
	public Student(int rno,String name,Course[] courses)
	{
		super();
		this.rno=rno;
		this.name=name;
		this.courses=courses;
		
	}
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Course[] getCourses() {
		return courses;
	}
	public void setCourses(Course[] courses) {
		this.courses = courses;
	}
	
}
