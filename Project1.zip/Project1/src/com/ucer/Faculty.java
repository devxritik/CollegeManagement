package com.ucer;

public class Faculty {
	private String facultyName;
	private Course[] courses;
	public Faculty(String facultyName,Course[] courses)
	{
		super();
		this.facultyName=facultyName;
		this.courses=courses;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public Course[] getCourses() {
		return courses;
	}
	public void setCourses(Course[] courses) {
		this.courses = courses;
	}

}
